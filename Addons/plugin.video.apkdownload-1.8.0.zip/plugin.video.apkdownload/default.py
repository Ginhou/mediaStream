import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys
import urllib2,urllib
import re
import downloader


ADDON=xbmcaddon.Addon(id='plugin.video.apkdownload')

    
VERSION = "1.7.2"
ADDON_NAME = "APK Download"


dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()
installerpath  =  xbmc.translatePath(os.path.join('special://home','addons','plugin.video.apkdownload'))
skinspath  =  xbmc.translatePath(os.path.join('special://home','addons','plugin.video.apkdownload','resources','skins'))
fanart_background = xbmc.translatePath(os.path.join(installerpath,'fanart.jpg'))
install_icon = xbmc.translatePath(os.path.join(skinspath,'install.png'))
uninstall_icon = xbmc.translatePath(os.path.join(skinspath,'uninstall.png'))
settings_icon = xbmc.translatePath(os.path.join(skinspath,'settings.png'))
feedback_icon = xbmc.translatePath(os.path.join(skinspath,'feedback.png'))
    
def CATEGORIES():
    addDir2('[COLOR white]Install Apps[/COLOR]','http://mega-tron.tv/apps/',4,install_icon,fanart_background,'')
    addDir2('[COLOR white]Uninstall Apps[/COLOR]','http://mega-tron.tv/apps/',5,uninstall_icon,fanart_background,'')
    addDir2('[COLOR white]App Settings[/COLOR]','http://mega-tron.tv/apps/',6,settings_icon,fanart_background,'')
    addDir('[COLOR white]Settings[/COLOR]','http://mega-tron.tv/apps/',7,settings_icon,fanart_background,'')
    addDir('[COLOR white]Feedback[/COLOR]','http://mega-tron.tv/apps/',8,feedback_icon,fanart_background,'')
    setView('movies', 'MAIN')

def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def InstallApp():
    link = OPEN_URL('http://mega-tron.tv/apkdownload/install.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,description in match:
        addDir(name,url,1,iconimage,fanart_background,description)
    setView('movies', 'MAIN')

def UninstallApp():
    link = OPEN_URL('http://mega-tron.tv/apkdownload/uninstall.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,description in match:
        addDir2(name,url,2,iconimage,fanart_background,description)
    setView('movies', 'MAIN')

def AppSettings():
    link = OPEN_URL('http://mega-tron.tv/apkdownload/uninstall.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,description in match:
        addDir2(name,url,3,iconimage,fanart_background,description)
    setView('movies', 'MAIN')

def OpenSettings():
    # KitKat and earlier
    xbmc.executebuiltin('StartAndroidActivity(com.android.settings)')
    # Lolipop and later
    xbmc.executebuiltin('StartAndroidActivity(com.android.tv.settings)')

def Feedback():
    dialog.ok('[COLOR yellow]Help make APK Download better[/COLOR]','[COLOR white]-Report dead and outdated apps[/COLOR]','[COLOR yellow]-Suggest new apps[/COLOR]','[COLOR white]-Contact apkdownload@mega-tron.tv[/COLOR]')    

def install(name,url,description):
    choice = xbmcgui.Dialog().yesno("[COLOR red]CAUTION[/COLOR]","[COLOR yellow]Do you want to INSTALL this app?[/COLOR]",name,"",yeslabel="Yes",nolabel="No")
    if choice == 1:
        downloadpath = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        dp.create(ADDON_NAME,"Downloading...",name,'Please wait...')
        lib=os.path.join(downloadpath,name+'.apk')
        downloader.download(url, lib, dp)
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        dialog.ok(ADDON_NAME,"Download finished...","","Click OK to install " + name + "")
        xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
        dialog.ok(ADDON_NAME,"","App Install Complete","Enjoy!")
        try: os.remove(lib)
        except: pass
    else:
        return

def uninstall(name,url,description):
    choice = xbmcgui.Dialog().yesno("[COLOR red]CAUTION[/COLOR]","[COLOR yellow]Do you really want to UNINSTALL this app?[/COLOR]",name,"",yeslabel="Yes",nolabel="No")
    if choice == 1:
        xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.DELETE",,"package:'+description+'")')
    else:
        return

def appsettings(name,url,description):
    choice = xbmcgui.Dialog().yesno("[COLOR red]CAUTION[/COLOR]","[COLOR yellow]Do you want the settings for this app?[/COLOR]",name,"",yeslabel="Yes",nolabel="No")
    if choice == 1:
        xbmc.executebuiltin('StartAndroidActivity("","android.settings.APPLICATION_DETAILS_SETTINGS",,"package:'+description+'","com.android.settings/.applications.InstalledAppDetails")')
        return
    else:
        return

def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def addDir2(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(ADDON_NAME)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        

if mode==None or url==None or len(url)<1:
        CATEGORIES()

elif mode==1:
        install(name,url,description)

elif mode==2:
        uninstall(name,url,description)

elif mode==3:
        appsettings(name,url,description)

elif mode==4:
        InstallApp()

elif mode==5:
        UninstallApp()

elif mode==6:
        AppSettings()

elif mode==7:
        OpenSettings()

elif mode==8:
        Feedback()


xbmcplugin.endOfDirectory(int(sys.argv[1]))

